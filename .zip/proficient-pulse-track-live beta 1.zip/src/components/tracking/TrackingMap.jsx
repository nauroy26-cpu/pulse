import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Polyline, CircleMarker, useMap } from 'react-leaflet';
import L from 'leaflet';

function AutoFit({ points, follow }) {
  const map = useMap();
  const firstFit = useRef(false);

  useEffect(() => {
    if (!points || points.length === 0) return;
    if (!firstFit.current) {
      if (points.length === 1) {
        map.setView([points[0].lat, points[0].lng], 15);
      } else {
        const bounds = L.latLngBounds(points.map(p => [p.lat, p.lng]));
        map.fitBounds(bounds, { padding: [40, 40] });
      }
      firstFit.current = true;
    } else if (follow && points.length > 0) {
      const last = points[points.length - 1];
      map.panTo([last.lat, last.lng], { animate: true, duration: 0.8 });
    }
  }, [points, follow, map]);

  return null;
}

export default function TrackingMap({ points = [], follow = true, center = [46.5, 2.5], zoom = 5 }) {
  const latLngs = points.map(p => [p.lat, p.lng]);
  const last = points[points.length - 1];

  return (
    <div className="relative w-full h-full rounded-2xl overflow-hidden ring-1 ring-border">
      <MapContainer
        center={last ? [last.lat, last.lng] : center}
        zoom={last ? 14 : zoom}
        scrollWheelZoom
        className="w-full h-full"
        style={{ minHeight: 300 }}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
          attribution='<span style="color:#333">&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/">CARTO</a></span>'
          maxZoom={19}
        />

        {/* Shadow trail */}
        {latLngs.length >= 2 && (
          <Polyline
            positions={latLngs}
            pathOptions={{ color: '#000', weight: 8, opacity: 0.5 }}
          />
        )}
        {/* Primary lime trail */}
        {latLngs.length >= 2 && (
          <Polyline
            positions={latLngs}
            pathOptions={{ color: 'hsl(75, 95%, 55%)', weight: 4, opacity: 0.95, lineCap: 'round', lineJoin: 'round' }}
          />
        )}

        {/* Start point */}
        {points[0] && (
          <CircleMarker
            center={[points[0].lat, points[0].lng]}
            radius={6}
            pathOptions={{ color: '#fff', weight: 2, fillColor: 'hsl(18, 85%, 55%)', fillOpacity: 1 }}
          />
        )}

        {/* Current point */}
        {last && (
          <>
            <CircleMarker
              center={[last.lat, last.lng]}
              radius={14}
              pathOptions={{ color: 'hsl(75, 95%, 55%)', weight: 2, fillColor: 'hsl(75, 95%, 55%)', fillOpacity: 0.15 }}
            />
            <CircleMarker
              center={[last.lat, last.lng]}
              radius={7}
              pathOptions={{ color: '#111', weight: 2, fillColor: 'hsl(75, 95%, 55%)', fillOpacity: 1 }}
            />
          </>
        )}

        <AutoFit points={points} follow={follow} />
      </MapContainer>
    </div>
  );
}