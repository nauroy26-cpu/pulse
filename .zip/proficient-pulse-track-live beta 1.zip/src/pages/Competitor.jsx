import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Radio, AlertTriangle, Maximize, Minimize, Play, Square, Pause, Trash2, FileDown, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import TopoBackground from '@/components/tracking/TopoBackground';
import TrackingMap from '@/components/tracking/TrackingMap';
import PulseDot from '@/components/tracking/PulseDot';
import useCompetitorTracking from '@/lib/useCompetitorTracking';
import { totalDistance, formatDistance, formatDuration, msToKmh } from '@/lib/trackingUtils';
import { exportTrackGPX } from '@/lib/exportGpx';

export default function Competitor() {
  const navigate = useNavigate();
  const pseudo = localStorage.getItem('pulse:pseudo') || '';

  useEffect(() => {
    if (!pseudo) navigate('/', { replace: true });
  }, [pseudo, navigate]);

  const [isExporting, setIsExporting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  const { isTracking, isPaused, points, start, stop, pause, resume, clearAll, loadExisting } = useCompetitorTracking({ onError: (m) => toast.error(m) });

  useEffect(() => {
    if (pseudo) loadExisting(pseudo);
  }, [pseudo, loadExisting]);

  const stats = useMemo(() => {
    const dist = totalDistance(points);
    const first = points[0];
    const last = points[points.length - 1];
    const duration = first && last ? new Date(last.recorded_at) - new Date(first.recorded_at) : 0;
    const avgSpeed = duration > 0 ? (dist / (duration / 1000)) * 3.6 : 0;
    const currentSpeed = last ? msToKmh(last.speed || 0) : 0;
    return {
      distance: formatDistance(dist),
      duration: formatDuration(duration),
      avg: avgSpeed.toFixed(1),
      current: currentSpeed.toFixed(1),
      count: points.length,
    };
  }, [points]);

  const handleStart = async () => { await start(pseudo); toast.success(`Live · ${pseudo}`); };
  const handleStop = () => { stop(); toast('Session stoppée', { icon: '⏹' }); };
  const handlePauseResume = () => {
    if (isPaused) { resume(); toast('Reprise', { icon: '▶' }); }
    else { pause(); toast('En pause', { icon: '⏸' }); }
  };
  const handleClear = async () => {
    if (!confirm(`Effacer les données de ${pseudo} ?`)) return;
    setIsClearing(true);
    try { await clearAll(pseudo); toast.success('Historique effacé'); }
    finally { setIsClearing(false); }
  };
  const handleExport = async () => {
    if (points.length === 0) { toast.error('Aucune donnée'); return; }
    setIsExporting(true);
    try { exportTrackGPX({ displayName: pseudo, points }); toast.success('GPX exporté'); }
    finally { setIsExporting(false); }
  };

  if (!pseudo) return null;

  return (
    <div className="h-screen bg-background relative grain overflow-hidden flex flex-col">
      <TopoBackground />

      {/* Header */}
      <header className="relative z-10 px-4 md:px-8 pt-4 pb-2 flex items-center justify-between shrink-0">
        <Link to="/" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition">
          <ArrowLeft className="w-3.5 h-3.5" /> Retour
        </Link>

        <div className="flex items-center gap-2 glass rounded-full px-3 py-1.5">
          {isTracking ? <PulseDot size={8} /> : <span className="w-2 h-2 rounded-full bg-muted-foreground/50" />}
          <span className="font-mono text-sm font-medium">{pseudo}</span>
          <span className={`text-[10px] font-mono uppercase tracking-widest ${isTracking && !isPaused ? 'text-primary' : isPaused ? 'text-accent' : 'text-muted-foreground'}`}>
            {isTracking ? (isPaused ? 'Paused' : 'Live') : 'Standby'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg hover:bg-secondary/60 transition text-muted-foreground hover:text-foreground"
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>
          <Radio className="w-3.5 h-3.5 text-muted-foreground" />
        </div>
      </header>

      {/* Main */}
      <main className="relative z-10 flex-1 px-4 md:px-8 pb-4 grid lg:grid-cols-5 gap-4 min-h-0">

        {/* Left panel */}
        <div className="lg:col-span-2 flex flex-col gap-3 min-h-0">

          {/* Stats grid - 2x2 */}
          <div className="grid grid-cols-2 gap-2 shrink-0">
            {[
              { label: 'Distance', value: stats.distance.split(' ')[0], unit: 'km', accent: true },
              { label: 'Durée', value: stats.duration, unit: '' },
              { label: 'Vit. instantanée', value: stats.current, unit: 'km/h' },
              { label: 'Vit. moyenne', value: stats.avg, unit: 'km/h' },
            ].map(({ label, value, unit, accent }) => (
              <div key={label} className={`glass rounded-xl p-3 text-center ${accent ? 'ring-1 ring-primary/40' : ''}`}>
                <div className="text-[9px] uppercase tracking-widest text-muted-foreground font-mono">{label}</div>
                <div className={`font-display text-2xl leading-tight mt-1 ${accent ? 'text-primary' : ''}`}>{value}</div>
                {unit && <div className="text-[9px] text-muted-foreground font-mono">{unit}</div>}
              </div>
            ))}
          </div>

          {/* Controls */}
          <div className="grid grid-cols-2 gap-2 shrink-0">
            {!isTracking ? (
              <button
                onClick={handleStart}
                className="h-12 rounded-xl bg-primary text-primary-foreground font-display text-sm tracking-wide flex items-center justify-center gap-2 glow-primary hover:bg-primary/90 transition col-span-2"
              >
                <Play className="w-4 h-4" fill="currentColor" /> START
              </button>
            ) : (
              <>
                <button
                  onClick={handlePauseResume}
                  className={`h-12 rounded-xl font-display text-sm tracking-wide flex items-center justify-center gap-2 transition ${
                    isPaused
                      ? 'bg-primary text-primary-foreground hover:bg-primary/90 glow-primary'
                      : 'bg-secondary/80 border border-border text-foreground hover:bg-secondary'
                  }`}
                >
                  {isPaused
                    ? <><Play className="w-4 h-4" fill="currentColor" /> RESUME</>
                    : <><Pause className="w-4 h-4" fill="currentColor" /> PAUSE</>
                  }
                </button>
                <button
                  onClick={handleStop}
                  className="h-12 rounded-xl bg-destructive text-destructive-foreground font-display text-sm tracking-wide flex items-center justify-center gap-2 hover:bg-destructive/90 transition"
                >
                  <Square className="w-4 h-4" fill="currentColor" /> STOP
                </button>
              </>
            )}
            <button
              onClick={handleClear}
              disabled={isTracking || isClearing}
              className="h-10 rounded-xl bg-secondary/60 border border-border text-sm font-display flex items-center justify-center gap-1.5 hover:bg-secondary transition disabled:opacity-40"
            >
              {isClearing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />} Clear
            </button>
            <button
              onClick={handleExport}
              disabled={isExporting}
              className="h-10 rounded-xl bg-secondary/60 border border-border text-sm font-display flex items-center justify-center gap-1.5 hover:bg-secondary transition disabled:opacity-40"
            >
              {isExporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />} GPX
            </button>
          </div>

          {/* GPS warning */}
          {!navigator.geolocation && (
            <div className="flex items-center gap-1 text-[10px] font-mono text-destructive uppercase tracking-wider shrink-0">
              <AlertTriangle className="w-3 h-3" /> GPS indisponible
            </div>
          )}
        </div>

        {/* Map */}
        <div className="lg:col-span-3 min-h-0 h-full">
          <TrackingMap key={points.length === 0 ? 'empty' : 'active'} points={points} follow={isTracking} />
        </div>
      </main>
    </div>
  );
}