import React, { useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Eye, WifiOff, User, Maximize, Minimize } from 'lucide-react';
import TopoBackground from '@/components/tracking/TopoBackground';
import TrackingMap from '@/components/tracking/TrackingMap';
import StatTile from '@/components/ui/StatTile';
import PulseDot from '@/components/tracking/PulseDot';
import usePublicTracking from '@/lib/usePublicTracking';
import { totalDistance, formatDistance, formatDuration, msToKmh } from '@/lib/trackingUtils';

export default function Public() {
  const navigate = useNavigate();
  const followPseudo = localStorage.getItem('pulse:follow_pseudo') || '';
  const followDisplay = localStorage.getItem('pulse:follow') || followPseudo;
  const [isFullscreen, setIsFullscreen] = React.useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  React.useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  useEffect(() => {
    if (!followPseudo) navigate('/', { replace: true });
  }, [followPseudo, navigate]);

  const { points, isLive, lastUpdate } = usePublicTracking(followDisplay || followPseudo);

  const stats = useMemo(() => {
    const dist = totalDistance(points);
    const first = points[0];
    const last = points[points.length - 1];
    const duration = first && last ? new Date(last.recorded_at) - new Date(first.recorded_at) : 0;
    const avgSpeed = duration > 0 ? (dist / (duration / 1000)) * 3.6 : 0;
    const currentSpeed = last ? msToKmh(last.speed || 0) : 0;
    const displayName = last?.display_name || first?.display_name || followDisplay;
    return {
      displayName,
      distance: formatDistance(dist),
      duration: formatDuration(duration),
      avg: avgSpeed.toFixed(1),
      current: currentSpeed.toFixed(1),
      count: points.length,
    };
  }, [points, followDisplay]);

  if (!followPseudo) return null;

  return (
    <div className="min-h-screen bg-background relative grain overflow-hidden">
      <TopoBackground />

      <header className="relative z-10 px-4 md:px-10 pt-6 flex items-center justify-between">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition">
          <ArrowLeft className="w-4 h-4" /> Retour
        </Link>
        <div className="flex items-center gap-2.5 glass rounded-full px-4 py-2">
          <User className="w-4 h-4 text-primary" />
          <span className="font-mono text-sm font-medium text-foreground">{stats.displayName || followDisplay}</span>
          {isLive ? <PulseDot size={8} /> : <span className="w-2 h-2 rounded-full bg-muted-foreground" />}
        </div>
        <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-[0.2em] text-muted-foreground">
          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg hover:bg-secondary/60 transition text-muted-foreground hover:text-foreground"
            title={isFullscreen ? 'Quitter le plein écran' : 'Plein écran'}
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>
          <Eye className="w-3.5 h-3.5" />
          Public
        </div>
      </header>

      <main className="relative z-10 px-4 md:px-10 pt-6 pb-16 max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-3">
          {isLive ? <PulseDot /> : <span className="w-3 h-3 rounded-full bg-muted" />}
          <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono">
            {isLive ? 'Live · Position en direct' : (points.length > 0 ? 'Historique · Athlète hors ligne' : 'Aucun signal')}
          </div>
        </div>
        <h1 className="font-display text-5xl md:text-7xl leading-[0.9] tracking-tight">
          Suis un athlète,<br /><span className="text-primary">en direct.</span>
        </h1>

        <div className="mt-10 grid lg:grid-cols-5 gap-5">
          {/* Left: stats */}
          <div className="lg:col-span-2 space-y-4">
            <div className="glass rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono">Athlète suivi</div>
                  <div className="font-display text-2xl mt-1">{stats.displayName || followDisplay}</div>
                </div>
                {points.length === 0 && (
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <WifiOff className="w-3.5 h-3.5" /> Aucun signal
                  </div>
                )}
              </div>

              {/* Recording status indicator */}
              <div className={`flex items-center gap-3 rounded-xl px-4 py-3 mb-4 ${isLive ? 'bg-primary/10 ring-1 ring-primary/40' : 'bg-secondary/40 ring-1 ring-border'}`}>
                <div className="relative flex items-center justify-center shrink-0">
                  {isLive ? (
                    <>
                      <span className="absolute w-5 h-5 rounded-full bg-primary/40 animate-ping" />
                      <span className="relative w-3 h-3 rounded-full bg-primary" />
                    </>
                  ) : (
                    <span className="w-3 h-3 rounded-full bg-muted-foreground/50" />
                  )}
                </div>
                <div>
                  <div className={`text-sm font-display leading-tight ${isLive ? 'text-primary' : 'text-muted-foreground'}`}>
                    {isLive ? 'Enregistrement actif' : 'Enregistrement arrêté'}
                  </div>
                  <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mt-0.5">
                    {isLive ? `GPS · Signal reçu · ${lastUpdate ? lastUpdate.toLocaleTimeString('fr-FR') : '—'}` : 'Compétiteur hors session'}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <StatTile label="Distance" value={stats.distance.split(' ')[0]} unit="km" accent />
                <StatTile label="Durée" value={stats.duration} unit="" />
                <StatTile label="Vitesse" value={stats.current} unit="km/h" />
                <StatTile label="Moyenne" value={stats.avg} unit="km/h" />
              </div>

              {lastUpdate && (
                <div className="mt-4 text-[10px] font-mono text-muted-foreground uppercase tracking-wider">
                  MAJ · {lastUpdate.toLocaleTimeString('fr-FR')} · {stats.count} pts
                </div>
              )}
            </div>
          </div>

          {/* Right: map */}
          <div className="lg:col-span-3 h-[420px] lg:h-[640px]">
            <TrackingMap points={points} follow={isLive} />
          </div>
        </div>
      </main>
    </div>
  );
}