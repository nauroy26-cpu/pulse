import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Eye, Bike, Mountain, ArrowRight, ArrowUpRight, Search, Loader2, Radio, User, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import TopoBackground from '@/components/tracking/TopoBackground';
import PulseDot from '@/components/tracking/PulseDot';

/* ── Competitor modal ─────────────────────────────────────────── */
function CompetitorModal({ onClose }) {
  const [pseudo, setPseudo] = useState(() => localStorage.getItem('pulse:pseudo') || '');
  const navigate = useNavigate();
  const inputRef = useRef(null);

  useEffect(() => { setTimeout(() => inputRef.current?.focus(), 80); }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!pseudo.trim()) return;
    localStorage.setItem('pulse:pseudo', pseudo.trim());
    navigate('/competitor');
  };

  return (
    <ModalShell onClose={onClose}>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shrink-0">
          <Mountain className="w-5 h-5 text-primary-foreground" strokeWidth={2.2} />
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono">01 · Athlète</div>
          <h2 className="font-display text-2xl leading-tight">Ton pseudo</h2>
        </div>
      </div>

      <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
        Identifie ta session. Le public te retrouvera avec ce nom en temps réel.
      </p>

      <form onSubmit={handleSubmit} className="space-y-3">
        <div className="relative">
          <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            ref={inputRef}
            type="text"
            value={pseudo}
            onChange={(e) => setPseudo(e.target.value)}
            placeholder="ex: Maxime_Trail"
            className="w-full h-13 py-3 bg-secondary/40 border border-border rounded-xl pl-11 pr-4 font-mono text-base text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
          />
        </div>
        <button
          type="submit"
          disabled={!pseudo.trim()}
          className="w-full h-13 py-3 rounded-xl bg-primary text-primary-foreground font-display text-base tracking-wide hover:bg-primary/90 disabled:opacity-40 transition flex items-center justify-center gap-2 glow-primary"
        >
          ENTRER <ArrowRight className="w-4 h-4" />
        </button>
      </form>
    </ModalShell>
  );
}

/* ── Public modal ─────────────────────────────────────────────── */
function PublicModal({ onClose }) {
  const [athletes, setAthletes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    async function load() {
      try {
        const data = await base44.entities.TrackPoint.list('-recorded_at', 500);
        const map = new Map();
        (data || []).forEach((p) => {
          if (!map.has(p.pseudo)) map.set(p.pseudo, p);
        });
        const list = [...map.values()].sort((a, b) => new Date(b.recorded_at) - new Date(a.recorded_at));
        setAthletes(list);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const filtered = athletes.filter((a) =>
    (a.display_name || a.pseudo).toLowerCase().includes(search.toLowerCase())
  );

  const isLive = (p) => Date.now() - new Date(p.recorded_at).getTime() < 30000;

  const handleSelect = (athlete) => {
    const name = athlete.display_name || athlete.pseudo;
    localStorage.setItem('pulse:follow', name);
    localStorage.setItem('pulse:follow_pseudo', athlete.pseudo);
    navigate('/public');
  };

  return (
    <ModalShell onClose={onClose}>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center shrink-0">
          <Eye className="w-5 h-5 text-foreground" strokeWidth={2.2} />
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono">02 · Public</div>
          <h2 className="font-display text-2xl leading-tight">Choisir un athlète</h2>
        </div>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Rechercher…"
          className="w-full h-11 bg-secondary/40 border border-border rounded-xl pl-10 pr-4 font-mono text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition"
        />
      </div>

      <div className="overflow-y-auto max-h-[340px] space-y-2 pr-1">
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-5 h-5 text-primary animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground text-sm font-mono">
            {search ? 'Aucun résultat.' : 'Aucune session enregistrée.'}
          </div>
        ) : (
          filtered.map((athlete) => {
            const live = isLive(athlete);
            const displayName = athlete.display_name || athlete.pseudo;
            return (
              <motion.button
                key={athlete.pseudo}
                whileHover={{ x: 3 }}
                transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                onClick={() => handleSelect(athlete)}
                className="w-full glass rounded-xl px-4 py-3 flex items-center justify-between hover:ring-1 hover:ring-primary/40 transition group"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-display font-bold shrink-0 ${live ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'}`}>
                    {displayName[0]?.toUpperCase()}
                  </div>
                  <div className="text-left">
                    <div className="font-display text-base leading-tight">{displayName}</div>
                    <div className="text-[11px] font-mono text-muted-foreground mt-0.5 flex items-center gap-1.5">
                      {live ? (
                        <span className="flex items-center gap-1 text-primary"><PulseDot size={7} /> LIVE</span>
                      ) : (
                        <span className="flex items-center gap-1"><Radio className="w-3 h-3" /> Hors ligne</span>
                      )}
                      <span>·</span>
                      <span>{formatRelTime(athlete.recorded_at)}</span>
                    </div>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all shrink-0" />
              </motion.button>
            );
          })
        )}
      </div>
    </ModalShell>
  );
}

/* ── Modal shell ──────────────────────────────────────────────── */
function ModalShell({ children, onClose }) {
  // Close on backdrop click
  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />

      <motion.div
        className="relative z-10 w-full max-w-md glass rounded-3xl p-6 shadow-2xl"
        initial={{ scale: 0.93, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.93, y: 20 }}
        transition={{ type: 'spring', stiffness: 320, damping: 28 }}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-secondary/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition"
        >
          <X className="w-4 h-4" />
        </button>
        {children}
      </motion.div>
    </motion.div>
  );
}

/* ── Mode card ────────────────────────────────────────────────── */
function ModeCard({ kicker, title, description, icon: Icon, accent, onClick }) {
  return (
    <motion.button
      whileHover={{ y: -4 }}
      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
      onClick={onClick}
      className="group relative text-left w-full overflow-hidden rounded-3xl glass p-6 md:p-8 h-full transition-all hover:ring-1 hover:ring-primary/40"
    >
      <div className="flex items-start justify-between">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${accent ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground'}`}>
          <Icon className="w-6 h-6" strokeWidth={2.2} />
        </div>
        <ArrowUpRight className="w-5 h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
      </div>
      <div className="mt-8">
        <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono mb-2">{kicker}</div>
        <h3 className="font-display text-3xl md:text-4xl leading-[0.95]">{title}</h3>
        <p className="mt-4 text-sm md:text-base text-muted-foreground leading-relaxed max-w-sm">{description}</p>
      </div>
    </motion.button>
  );
}

/* ── Page ─────────────────────────────────────────────────────── */
export default function Home() {
  const [modal, setModal] = useState(null); // 'competitor' | 'public' | null

  return (
    <div className="min-h-screen bg-background relative grain overflow-hidden">
      <TopoBackground />

      {/* Header */}
      <header className="relative z-10 px-6 md:px-12 pt-8 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <Activity className="w-4 h-4 text-primary-foreground" strokeWidth={3} />
          </div>
          <span className="font-display text-xl tracking-tight">PULSE</span>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
          <PulseDot size={8} />
          <span className="uppercase tracking-[0.2em]">Live · 2026</span>
        </div>
      </header>

      {/* Hero */}
      <section className="relative z-10 px-6 md:px-12 pt-16 md:pt-24 pb-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }} className="max-w-5xl">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/50 border border-border/50 text-xs font-mono uppercase tracking-[0.2em] text-muted-foreground">
            <Bike className="w-3.5 h-3.5" /> Cyclisme · Trail · Running
          </div>
          <h1 className="mt-6 font-display text-[14vw] md:text-[9vw] leading-[0.88] tracking-tight text-balance">
            Track the <span className="text-primary">pulse</span><br />of every move.
          </h1>
          <p className="mt-8 text-base md:text-xl text-muted-foreground max-w-2xl leading-relaxed">
            Plateforme de suivi sportif en temps réel. Enregistrez votre course, partagez votre position, suivez vos athlètes — tout, en direct.
          </p>
        </motion.div>
      </section>

      {/* Cards */}
      <section className="relative z-10 px-6 md:px-12 pb-24">
        <div className="grid md:grid-cols-2 gap-4 md:gap-6 max-w-5xl">
          <ModeCard
            kicker="01 · Athlète"
            title="Espace Compétiteur"
            description="Lance une session, transmets ta position en direct. Start, stop, export PDF. Ton pseudo, ton tracé."
            icon={Mountain}
            accent
            onClick={() => setModal('competitor')}
          />
          <ModeCard
            kicker="02 · Public"
            title="Espace Spectateur"
            description="Suis un athlète en direct. Visualise sa position, son historique et son évolution sur la carte."
            icon={Eye}
            onClick={() => setModal('public')}
          />
        </div>

        <div className="mt-16 md:mt-24 flex flex-wrap items-center justify-between gap-6 pt-8 border-t border-border/50 max-w-5xl">
          <div className="font-mono text-xs text-muted-foreground uppercase tracking-[0.2em]">Pulse · Real-time sport tracking</div>
          <div className="flex items-center gap-6 font-mono text-xs text-muted-foreground">
            <span>GPS · 5s</span><span>Live · Polyline</span><span>Export · PDF</span>
          </div>
        </div>
      </section>

      {/* Modals */}
      <AnimatePresence>
        {modal === 'competitor' && <CompetitorModal onClose={() => setModal(null)} />}
        {modal === 'public' && <PublicModal onClose={() => setModal(null)} />}
      </AnimatePresence>
    </div>
  );
}

function formatRelTime(dateStr) {
  const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (diff < 60) return `il y a ${diff}s`;
  if (diff < 3600) return `il y a ${Math.floor(diff / 60)}min`;
  if (diff < 86400) return `il y a ${Math.floor(diff / 3600)}h`;
  return `il y a ${Math.floor(diff / 86400)}j`;
}