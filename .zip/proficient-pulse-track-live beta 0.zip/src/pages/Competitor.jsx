import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Radio, AlertTriangle, User, Maximize, Minimize } from 'lucide-react';
import { toast } from 'sonner';
import TopoBackground from '@/components/tracking/TopoBackground';
import TrackingMap from '@/components/tracking/TrackingMap';
import CompetitorControls from '@/components/tracking/CompetitorControls';
import StatTile from '@/components/ui/StatTile';
import PulseDot from '@/components/tracking/PulseDot';
import useCompetitorTracking from '@/lib/useCompetitorTracking';
import { totalDistance, formatDistance, formatDuration, msToKmh } from '@/lib/trackingUtils';
import { exportTrackPDF } from '@/lib/exportPdf';

export default function Competitor() {
  const navigate = useNavigate();
  const pseudo = localStorage.getItem('pulse:pseudo') || '';

  // Redirect if no pseudo
  useEffect(() => {
    if (!pseudo) navigate('/', { replace: true });
  }, [pseudo, navigate]);

  const [isExporting, setIsExporting] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', handler);
    return () => document.removeEventListener('fullscreenchange', handler);
  }, []);

  const {
    isTracking, points, start, stop, clearAll, loadExisting,
  } = useCompetitorTracking({ onError: (m) => toast.error(m) });

  // Load existing points on mount
  useEffect(() => {
    if (pseudo) loadExisting(pseudo);
  }, [pseudo, loadExisting]);

  const stats = useMemo(() => {
    const dist = totalDistance(points);
    const first = points[0];
    const last = points[points.length - 1];
    const duration = first && last ? new Date(last.recorded_at) - new Date(first.recorded_at) : 0;
    const avgSpeed = duration > 0 ? (dist / (duration / 1000)) * 3.6 : 0;
    const currentSpeed = last ? msToKmh(last.speed || 0) : 0;
    return {
      distance: formatDistance(dist),
      duration: formatDuration(duration),
      avg: avgSpeed.toFixed(1),
      current: currentSpeed.toFixed(1),
      count: points.length,
    };
  }, [points]);

  const handleStart = async () => {
    await start(pseudo);
    toast.success(`Tracking actif · ${pseudo}`);
  };

  const handleStop = () => {
    stop();
    toast('Session stoppée', { icon: '⏹' });
  };

  const handleClear = async () => {
    if (!confirm(`Effacer toutes les données de ${pseudo} ?`)) return;
    setIsClearing(true);
    try {
      await clearAll(pseudo);
      toast.success('Historique effacé');
    } finally {
      setIsClearing(false);
    }
  };

  const handleExport = async () => {
    if (points.length === 0) { toast.error('Aucune donnée à exporter'); return; }
    setIsExporting(true);
    try {
      exportTrackPDF({ displayName: pseudo, points });
      toast.success('PDF généré');
    } finally {
      setIsExporting(false);
    }
  };

  if (!pseudo) return null;

  return (
    <div className="min-h-screen bg-background relative grain overflow-hidden">
      <TopoBackground />

      <header className="relative z-10 px-4 md:px-10 pt-6 flex items-center justify-between">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition">
          <ArrowLeft className="w-4 h-4" /> Retour
        </Link>
        <div className="flex items-center gap-2.5 glass rounded-full px-4 py-2">
          <User className="w-4 h-4 text-primary" />
          <span className="font-mono text-sm font-medium text-foreground">{pseudo}</span>
          {isTracking && <PulseDot size={8} />}
        </div>
        <div className="flex items-center gap-3 text-xs font-mono uppercase tracking-[0.2em] text-muted-foreground">
          <button
            onClick={toggleFullscreen}
            className="p-1.5 rounded-lg hover:bg-secondary/60 transition text-muted-foreground hover:text-foreground"
            title={isFullscreen ? 'Quitter le plein écran' : 'Plein écran'}
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>
          <Radio className="w-3.5 h-3.5" />
          Athlète
        </div>
      </header>

      <main className="relative z-10 px-4 md:px-10 pt-6 pb-16 max-w-7xl mx-auto">
        <div className="flex items-center gap-3 mb-3">
          {isTracking && <PulseDot />}
          <div className="text-[10px] uppercase tracking-[0.3em] text-muted-foreground font-mono">
            {isTracking ? 'Live · Transmission active' : 'Standby'}
          </div>
        </div>
        <h1 className="font-display text-5xl md:text-7xl leading-[0.9] tracking-tight">
          Ta session,<br /><span className="text-primary">en direct.</span>
        </h1>

        <div className="mt-10 grid lg:grid-cols-5 gap-5">
          {/* Left: controls + stats */}
          <div className="lg:col-span-2 space-y-4">
            <CompetitorControls
              isTracking={isTracking}
              canStart={true}
              onStart={handleStart}
              onStop={handleStop}
              onClear={handleClear}
              onExport={handleExport}
              isExporting={isExporting}
              isClearing={isClearing}
            />

            <div className="grid grid-cols-2 gap-3">
              <StatTile label="Distance" value={stats.distance.split(' ')[0]} unit="km" accent />
              <StatTile label="Durée" value={stats.duration} unit="" />
              <StatTile label="Vitesse" value={stats.current} unit="km/h" />
              <StatTile label="Moyenne" value={stats.avg} unit="km/h" />
            </div>

            {!navigator.geolocation && (
              <div className="flex items-start gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/30 text-sm">
                <AlertTriangle className="w-4 h-4 text-destructive mt-0.5" />
                <span>GPS indisponible sur ce navigateur.</span>
              </div>
            )}
          </div>

          {/* Right: map */}
          <div className="lg:col-span-3 h-[420px] lg:h-[640px]">
            <TrackingMap points={points} follow={isTracking} />
          </div>
        </div>
      </main>
    </div>
  );
}